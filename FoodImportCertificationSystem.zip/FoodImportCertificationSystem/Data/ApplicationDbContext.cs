﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using FoodImportCertificationSystem.Models;

namespace FoodImportCertificationSystem.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<ImportedFood> ImportedFoods { get; set; }
        public DbSet<LabResult> LabResults { get; set; }
    }
}