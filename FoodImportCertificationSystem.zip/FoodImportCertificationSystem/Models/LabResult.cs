﻿using System.ComponentModel.DataAnnotations;

public class LabResult
{
    public int Id { get; set; }

    [Required]
    public int ImportedFoodId { get; set; }

    public ImportedFood? ImportedFood { get; set; }
    [Required]
    public string Parameter { get; set; }

    [Required]
    public string Value { get; set; }

    public string Conclusion { get; set; }

    public DateTime TestDate { get; set; } = DateTime.Now;
}