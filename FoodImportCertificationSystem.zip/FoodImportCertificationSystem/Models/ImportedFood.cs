﻿using System.ComponentModel.DataAnnotations;

public class ImportedFood
{
    public int Id { get; set; }

    [Required]
    public string Name { get; set; }

    [Required]
    public string CountryOfOrigin { get; set; }

    public string Description { get; set; }

    public string Status { get; set; } = "Нова";
    public string? RejectionReason { get; set; }
}