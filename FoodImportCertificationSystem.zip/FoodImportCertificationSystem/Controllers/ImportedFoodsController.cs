﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FoodImportCertificationSystem.Data;
using Microsoft.AspNetCore.Authorization;

namespace FoodImportCertificationSystem.Controllers
{
    public class ImportedFoodsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ImportedFoodsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ImportedFoods
        public async Task<IActionResult> Index()
        {
            return View(await _context.ImportedFoods.ToListAsync());
        }

        // GET: ImportedFoods/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var importedFood = await _context.ImportedFoods
                .FirstOrDefaultAsync(m => m.Id == id);
            if (importedFood == null)
            {
                return NotFound();
            }

            return View(importedFood);
        }
        [Authorize(Roles = "Вносител")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: ImportedFoods/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = "Вносител")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,CountryOfOrigin,Description,Status")] ImportedFood importedFood)
        {
            if (ModelState.IsValid)
            {
                _context.Add(importedFood);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(importedFood);
        }

        // GET: ImportedFoods/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var importedFood = await _context.ImportedFoods.FindAsync(id);
            if (importedFood == null)
            {
                return NotFound();
            }
            return View(importedFood);
        }

        // POST: ImportedFoods/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,CountryOfOrigin,Description,Status")] ImportedFood importedFood)
        {
            if (id != importedFood.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(importedFood);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ImportedFoodExists(importedFood.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(importedFood);
        }

        // GET: ImportedFoods/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var importedFood = await _context.ImportedFoods
                .FirstOrDefaultAsync(m => m.Id == id);
            if (importedFood == null)
            {
                return NotFound();
            }

            return View(importedFood);
        }

        // POST: ImportedFoods/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var importedFood = await _context.ImportedFoods.FindAsync(id);
            if (importedFood != null)
            {
                _context.ImportedFoods.Remove(importedFood);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        [Authorize(Roles = "Лаборант")]
        public async Task<IActionResult> StartProcessing(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "В процес";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        [Authorize(Roles = "Лаборант")]
        public async Task<IActionResult> MarkAsTested(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "Изследвана";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        [Authorize(Roles = "Инспектор")]
        public async Task<IActionResult> Approve(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "Одобрена";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Инспектор")]
        public async Task<IActionResult> Reject(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "Отказана";
            food.RejectionReason = "Отклонение от лабораторните показатели";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        [Authorize(Roles = "Инспектор")]
        public async Task<IActionResult> SendForDisinfection(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "Насочена за обеззаразяване";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Инспектор")]
        public async Task<IActionResult> SendForDestruction(int id)
        {
            var food = await _context.ImportedFoods.FindAsync(id);
            if (food == null)
            {
                return NotFound();
            }

            food.Status = "Насочена за унищожаване";
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
        private bool ImportedFoodExists(int id)
        {
            return _context.ImportedFoods.Any(e => e.Id == id);
        }
    }
}

