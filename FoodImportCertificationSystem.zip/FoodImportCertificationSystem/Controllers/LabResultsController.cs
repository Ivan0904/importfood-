﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FoodImportCertificationSystem.Data;

namespace FoodImportCertificationSystem.Controllers
{
    public class LabResultsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LabResultsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: LabResults
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.LabResults.Include(l => l.ImportedFood);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: LabResults/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var labResult = await _context.LabResults
                .Include(l => l.ImportedFood)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (labResult == null)
            {
                return NotFound();
            }

            return View(labResult);
        }

        // GET: LabResults/Create
        public IActionResult Create()
        {
            ViewData["ImportedFoodId"] = new SelectList(_context.ImportedFoods, "Id", "Name");
            return View();
        }

        // POST: LabResults/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ImportedFoodId,Parameter,Value,Conclusion,TestDate")] LabResult labResult)
        {
            if (ModelState.IsValid)
            {
                _context.Add(labResult);

                var food = await _context.ImportedFoods.FindAsync(labResult.ImportedFoodId);
                if (food != null)
                {
                    food.Status = "Изследвана";
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ImportedFoodId"] = new SelectList(_context.ImportedFoods, "Id", "Name", labResult.ImportedFoodId);
            return View(labResult);
        }

        // GET: LabResults/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var labResult = await _context.LabResults.FindAsync(id);
            if (labResult == null)
            {
                return NotFound();
            }
            ViewData["ImportedFoodId"] = new SelectList(_context.ImportedFoods, "Id", "Name", labResult.ImportedFoodId);
            return View(labResult);
        }

        // POST: LabResults/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ImportedFoodId,Parameter,Value,Conclusion,TestDate")] LabResult labResult)
        {
            if (id != labResult.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(labResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LabResultExists(labResult.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ImportedFoodId"] = new SelectList(_context.ImportedFoods, "Id", "Name", labResult.ImportedFoodId);
            return View(labResult);
        }

        // GET: LabResults/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var labResult = await _context.LabResults
                .Include(l => l.ImportedFood)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (labResult == null)
            {
                return NotFound();
            }

            return View(labResult);
        }

        // POST: LabResults/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var labResult = await _context.LabResults.FindAsync(id);
            if (labResult != null)
            {
                _context.LabResults.Remove(labResult);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LabResultExists(int id)
        {
            return _context.LabResults.Any(e => e.Id == id);
        }
    }
}
